from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.core.mail import send_mail
from django.db.models import F
from SIGNIN.models import Fund

# Create your views here.
#def webapp_create(request):
	#return HttpResponse()

#def webapp_detail(request): #retrieve
#	return HttpResponse("<h1>detail</h1>")

def homepage(request):    #list items
	if(request.method=='GET'):
		req = Fund.objects.filter(is_verified=True,TargetAmount__gt=F('CurrentAmount')).order_by('-id')[:6]
		print req
		context={
			'flag':False,
			'funds':req
		}
		if request.session.get('loggedin') == True:
			context['flag'] = True
		return render(request,"index.html",context)
	else:
		print request.POST
		email = request.POST.get('email')
		name = request.POST.get('name')
		message = request.POST.get('message')
		send_mail('Feedback from '+name,
			message+'\nName: '+name+'\nEmail: '+email,
			'vcare.nss.mec@gmail.com',
			['vcare.nss.mec@gmail.com'],
			fail_silently=False)
		return redirect('/')


def testmail(request):
	send_mail('Subject here', 'test','vcare.nss.mec@gmail.com',['vcare.nss.mec@gmail.com'], fail_silently=False)
	return HttpResponse("sent mail")

#ef webapp_delete(request):
#	return HttpResponse("<h1>delete</h1>")

#from django.core.mail import send_mail
#end_mail('Subject here', 'Here is the message.', 'from@example.com', ['to@example.com'], fail_silently=False)
