from django.shortcuts import render,redirect

from SIGNUP.models import SIGNUP
from SIGNIN.models import Fund
from django.http import HttpResponse,JsonResponse
from django.db.models import F
from nss.settings import STATICFILES_DIRS
import os

# Create your views here.

def sign_in(request):
	if request.method == 'GET':
		return render(request,"signin.html",{})
	else:
		print request.POST
		results = SIGNUP.objects.filter(E_mail=request.POST['username'])
		print results
		if len(results)!=0:
			if(results[0].Password!=request.POST['password']):
				return render(request,"signin.html",{'message':True})
			else:
				request.session['loggedin'] = True
				return redirect('/')
		return render(request,"signin.html",{'message':True})

def logout(request):
	request.session['loggedin'] = False
	return redirect('/')


# post
def Post(request):
	print request.POST
	if request.method == 'GET':
		return render(request,'start_fund.html',{})
	else:
		file = request.FILES['fileupload'].read()
		path = os.path.join(STATICFILES_DIRS[0])
		print path+request.POST['fundraiser']
		filename = request.POST['fundraiser']+'.jpg'
		pic = open(path+'/'+filename,'w+')
		pic.write(file)
		pic.close()
		fund = Fund(Firstname=request.POST['firstname'],
			Lastname=request.POST['lastname'],
			Address=request.POST['address'],
			Phone_Number= request.POST['phoneno'],
			E_mail= request.POST['emailid'],
			Fundraiserheading= request.POST['fundraiser'],
			Fundraiserdetails= request.POST['fundraiserdetails'],
			ProfilePicLink=filename,
			GovtVerficationId=request.POST['govtverificationid'],
			AdharCard=request.POST['adharno'],
		    TargetAmount=request.POST['targetamount'])
		fund.save()
		return redirect('/')

def detailView(request,id):
	res = Fund.objects.filter(AdharCard=id)
	print res
	if( len(res)==0 ):
		return redirect('/')
	flag = True
	if( request.session.get('loggedin')==None ):
		flag = False
	obj = res[0]
	objdicts = obj.__dict__
	context = {
		'flag': flag,
		'objs': objdicts
	}
	return render(request,'detail.html',context)

def activity(request):
	res = Fund.objects.filter(TargetAmount=F('CurrentAmount'))
	if( len(res)==0 ):
		return redirect('/')
	flag = True
	if( request.session.get('loggedin')==None ):
		flag = False
	context = {}
	context['funds'] = res
	context['flag'] = flag
	return render(request,'activity.html',context)