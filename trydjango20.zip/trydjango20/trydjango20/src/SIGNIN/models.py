from __future__ import unicode_literals

from django.db import models

class SIGNIN(models.Model):
	Username=models.CharField(max_length=120)
	Password=models.CharField(max_length=120)

	def __unicode__(self):
		return self.Username

	def __str__(self):
		return self.Username

class Fund(models.Model):
	Firstname=models.CharField(max_length=120)
	Lastname=models.CharField(max_length=120)
	Address=models.CharField(max_length=120)
	Phone_Number=models.CharField(max_length=120)
	E_mail=models.CharField(max_length=120)
	Fundraiserheading = models.CharField(max_length=200)
	Fundraiserdetails = models.CharField(max_length=500)
	ProfilePicLink = models.CharField(max_length=200)
	GovtVerficationId = models.CharField(max_length=200)
	AdharCard = models.CharField(max_length=30)
	TargetAmount = models.FloatField(null=True)
	CurrentAmount = models.FloatField(default=0.0)
	is_verified = models.BooleanField(default=False)

	def __str__(self):
		return self.Fundraiserheading