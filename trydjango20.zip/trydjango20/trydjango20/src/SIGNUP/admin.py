from django.contrib import admin
from .models import SIGNUP
# Register your models here.
admin.site.register(SIGNUP)